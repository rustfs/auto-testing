# Validation migration report

Cases: 158

- PASS: 0
- FAIL: 1
- INFRA_ERROR: 0
- BLOCKED: 0
- UNSUPPORTED: 0
- RUNNING: 0
- MISSING: 157

| Case | Source status | Verdict | Reason |
| --- | --- | --- | --- |
| pool.status | implemented | MISSING |  |
| pool.expand-and-rebalance | implemented | MISSING |  |
| pool.expansion-restart-persistence | implemented | MISSING |  |
| pool.rebalance-stop-resume | implemented | MISSING |  |
| pool.rebalance-live-io | implemented | MISSING |  |
| pool.decommission | implemented | MISSING |  |
| pool.decommission-cancel-clear-resume | implemented | MISSING |  |
| pool.decommission-restart-recovery | implemented | MISSING |  |
| pool.decommission-versioned-integrity | implemented | MISSING |  |
| pool.decommission-multipart-integrity | implemented | MISSING |  |
| pool.decommission-live-io | implemented | MISSING |  |
| pool.retired-config-removal | implemented | MISSING |  |
| pool.operation-guards | implemented | MISSING |  |
| heal.admin-healthy-noop | procedure-ready | MISSING |  |
| heal.admin-scope-isolation | procedure-ready | MISSING |  |
| heal.admin-token-cross-node-status | procedure-ready | MISSING |  |
| heal.admin-dry-run | procedure-ready | MISSING |  |
| heal.admin-overlap-and-force-start | procedure-ready | MISSING |  |
| heal.admin-stop-and-stale-token | procedure-ready | MISSING |  |
| heal.admin-invalid-request | procedure-ready | MISSING |  |
| heal.admin-authorization | procedure-ready | MISSING |  |
| heal.admin-nolock-safety | procedure-ready | MISSING |  |
| heal.admin-option-contract | procedure-ready | MISSING |  |
| heal.disk-loss-and-repair | procedure-ready | MISSING |  |
| heal.disk-readonly-and-permission | procedure-ready | MISSING |  |
| heal.disk-replacement-formatted | procedure-ready | MISSING |  |
| heal.disk-replacement-unformatted | procedure-ready | MISSING |  |
| heal.multiple-shard-loss | procedure-ready | MISSING |  |
| heal.read-quorum-boundary | procedure-ready | MISSING |  |
| heal.below-read-quorum | procedure-ready | MISSING |  |
| heal.below-write-quorum | procedure-ready | MISSING |  |
| heal.node-outage-rejoin | procedure-ready | MISSING |  |
| heal.disk-and-node-flapping | procedure-ready | MISSING |  |
| heal.missing-part-file | procedure-ready | MISSING |  |
| heal.data-shard-bitrot | procedure-ready | MISSING |  |
| heal.parity-shard-bitrot | procedure-ready | MISSING |  |
| heal.truncated-and-zeroed-shard | procedure-ready | MISSING |  |
| heal.missing-or-corrupt-xlmeta | procedure-ready | MISSING |  |
| heal.stale-version-rejoin | procedure-ready | MISSING |  |
| heal.conflicting-subquorum-authority | procedure-ready | MISSING |  |
| heal.metadata-payload-mismatch | procedure-ready | MISSING |  |
| heal.foreign-format-and-unknown-schema | procedure-ready | MISSING |  |
| heal.dangling-and-orphan-safety | procedure-ready | MISSING |  |
| heal.bucket-incarnation-recreation | procedure-ready | MISSING |  |
| heal.object-size-boundaries | procedure-ready | MISSING |  |
| heal.completed-multipart-object | procedure-ready | MISSING |  |
| heal.historical-versions | procedure-ready | MISSING |  |
| heal.delete-marker-semantics | procedure-ready | MISSING |  |
| heal.versioning-suspended-null | procedure-ready | MISSING |  |
| heal.object-metadata-and-tags | procedure-ready | MISSING |  |
| heal.range-head-and-conditions | procedure-ready | MISSING |  |
| heal.encrypted-objects | procedure-ready | MISSING |  |
| heal.object-lock-retention | procedure-ready | MISSING |  |
| heal.special-keys-and-pagination | procedure-ready | MISSING |  |
| heal.bucket-metadata-integrity | procedure-ready | MISSING |  |
| heal.manual-normal-attribution | procedure-ready | MISSING |  |
| heal.manual-deep-attribution | procedure-ready | MISSING |  |
| heal.read-repair-attribution | procedure-ready | MISSING |  |
| heal.scanner-cold-object-repair | procedure-ready | MISSING |  |
| heal.mrf-offline-write-replay | procedure-ready | MISSING |  |
| heal.replacement-auto-rebuild | procedure-ready | MISSING |  |
| heal.root-graceful-coordinator-restart | procedure-ready | MISSING |  |
| heal.target-graceful-restart | procedure-ready | MISSING |  |
| heal.target-process-crash | procedure-ready | MISSING |  |
| heal.coordinator-process-crash | procedure-ready | MISSING |  |
| heal.full-cluster-restart | procedure-ready | MISSING |  |
| heal.cancelled-task-restart | procedure-ready | MISSING |  |
| heal.checkpoint-and-mrf-corruption | procedure-ready | MISSING |  |
| heal.race-unversioned-overwrite | procedure-ready | MISSING |  |
| heal.race-versioned-put | procedure-ready | MISSING |  |
| heal.race-version-delete | procedure-ready | MISSING |  |
| heal.race-markers-and-batch-delete | procedure-ready | MISSING |  |
| heal.race-multipart-complete-abort | procedure-ready | MISSING |  |
| heal.race-copy-and-metadata-update | procedure-ready | MISSING |  |
| heal.race-ilm-expiry-and-transition | procedure-ready | MISSING |  |
| heal.race-replication-resync | procedure-ready | MISSING |  |
| heal.slow-io-and-eio | procedure-ready | MISSING |  |
| heal.enospc-inodes-and-quota | procedure-ready | MISSING |  |
| heal.network-partition-and-lock-quorum | procedure-ready | MISSING |  |
| heal.queue-pressure-and-admission | procedure-ready | MISSING |  |
| heal.lock-timeout-and-caller-abort | procedure-ready | FAIL | Heal source assertions did not pass on every required H1/H2 branch |
| heal.kms-and-tier-outage | procedure-ready | MISSING |  |
| heal.status-partial-disabled-unknown | procedure-ready | MISSING |  |
| heal.outcome-counters-and-error-truth | procedure-ready | MISSING |  |
| heal.incremental-cursor-and-truncation | procedure-ready | MISSING |  |
| heal.repeat-idempotency | procedure-ready | MISSING |  |
| heal.performance-abba | procedure-ready | MISSING |  |
| scanner.usage-convergence | planned | MISSING |  |
| heal.mixed-version-upgrade-rollback | procedure-ready | MISSING |  |
| heal.dedicated-host-forced-restart | procedure-ready | MISSING |  |
| heal.with-expansion-rebalance | procedure-ready | MISSING |  |
| heal.with-rebalance-stop-resume | procedure-ready | MISSING |  |
| heal.with-decommission | procedure-ready | MISSING |  |
| heal.with-decommission-cancel-clear | procedure-ready | MISSING |  |
| heal.after-retired-pool-removal | procedure-ready | MISSING |  |
| heal.multi-pool-target-isolation | procedure-ready | MISSING |  |
| heal.ec84-multi-set-restart | procedure-ready | MISSING |  |
| heal.long-soak | procedure-ready | MISSING |  |
| scanner.status-readiness | implemented | MISSING |  |
| ilm.configuration-roundtrip | implemented | MISSING |  |
| ilm.invalid-configuration | implemented | MISSING |  |
| ilm.current-expiration | implemented | MISSING |  |
| ilm.tag-filter-expiration | implemented | MISSING |  |
| ilm.disabled-rule | implemented | MISSING |  |
| ilm.rule-removal | implemented | MISSING |  |
| ilm.versioned-current-expiration | implemented | MISSING |  |
| ilm.noncurrent-expiration | implemented | MISSING |  |
| ilm.newer-noncurrent-retention | implemented | MISSING |  |
| ilm.delete-all-versions | implemented | MISSING |  |
| ilm.delete-marker-expiration | implemented | MISSING |  |
| ilm.multipart-expiration | implemented | MISSING |  |
| ilm.transition-and-restore | implemented | MISSING |  |
| ilm.restart-persistence | implemented | MISSING |  |
| bucket-replication.source-versioning-required | implemented | MISSING |  |
| bucket-replication.target-versioning-required | implemented | MISSING |  |
| bucket-replication.configuration-roundtrip | implemented | MISSING |  |
| bucket-replication.put-object | implemented | MISSING |  |
| bucket-replication.sync-put-object | implemented | MISSING |  |
| bucket-replication.prefix-filter | implemented | MISSING |  |
| bucket-replication.tag-filter | implemented | MISSING |  |
| bucket-replication.zero-byte-special-key | implemented | MISSING |  |
| bucket-replication.multipart-object | implemented | MISSING |  |
| bucket-replication.copy-object | implemented | MISSING |  |
| bucket-replication.delete-marker | implemented | MISSING |  |
| bucket-replication.version-delete | implemented | MISSING |  |
| bucket-replication.existing-object-enabled | implemented | MISSING |  |
| bucket-replication.existing-object-disabled | implemented | MISSING |  |
| bucket-replication.target-check | implemented | MISSING |  |
| bucket-replication.status-observability | implemented | MISSING |  |
| bucket-replication.outage-recovery | implemented | MISSING |  |
| bucket-replication.source-restart-recovery | implemented | MISSING |  |
| site-replication.unconfigured-info | implemented | MISSING |  |
| site-replication.invalid-credentials | implemented | MISSING |  |
| site-replication.add-and-info | implemented | MISSING |  |
| site-replication.status-observability | implemented | MISSING |  |
| site-replication.bucket-create | implemented | MISSING |  |
| site-replication.object-bidirectional | implemented | MISSING |  |
| site-replication.versioning-metadata | implemented | MISSING |  |
| site-replication.lifecycle-expiry-toggle | implemented | MISSING |  |
| site-replication.bucket-policy-metadata | implemented | MISSING |  |
| site-replication.object-tags | implemented | MISSING |  |
| site-replication.delete-convergence | implemented | MISSING |  |
| site-replication.iam-user-policy | implemented | MISSING |  |
| site-replication.iam-group-policy | implemented | MISSING |  |
| site-replication.service-account | implemented | MISSING |  |
| site-replication.peer-edit | implemented | MISSING |  |
| site-replication.resync | implemented | MISSING |  |
| site-replication.outage-recovery | implemented | MISSING |  |
| site-replication.restart-persistence | implemented | MISSING |  |
| site-replication.remove-all | implemented | MISSING |  |
| site-replication.service-account-rotation | implemented | MISSING |  |
| kms.sse-kms-round-trip | planned | MISSING |  |
| tiering.transition-and-restore | planned | MISSING |  |
| events.delivery | planned | MISSING |  |
| audit.request-correlation | planned | MISSING |  |
| iam.policy-enforcement | planned | MISSING |  |
| oidc.login-and-session | planned | MISSING |  |
| s3.basic-object-round-trip | planned | MISSING |  |

## Validation errors

- heal.lock-timeout-and-caller-abort: gate verdict is 'FAIL'
